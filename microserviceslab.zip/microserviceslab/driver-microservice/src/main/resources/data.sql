INSERT INTO driver (id, first_name, last_name, phone_number, vehicle_id) VALUES
  (0, 'Gigi', 'Wentworth (877-CASH-NOW)', '(787)555-321', 0),
  (1, 'Fu', 'Duh', '(787)668-543', 1),
  (2, 'Joe', 'Schmo', '(787)999-765', 2);
