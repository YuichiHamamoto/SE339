# Microservice Lab

## Vehicle Microservice
Stores vehicle information such as a vehicle's type and its
registration.
###### http://localhost:8080

## Driver Microservice
Stores driver information including the vehicle they currently
drive.
###### http://localhost:8081

## Usage Microservice
Stores vehicle location information based on specific points
in time.
###### http://localhost:8082